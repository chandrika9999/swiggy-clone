// 1. Declared compileComponentClassMetadata
// 2. standalone components


// 3. THEY ARE SUPPOSED TO BE LISTED AND DECLARED IN MODULES